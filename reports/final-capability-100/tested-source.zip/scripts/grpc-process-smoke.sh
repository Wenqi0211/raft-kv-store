#!/usr/bin/env bash
set -euo pipefail
PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$PROJECT_DIR"
bash scripts/maven.sh -q -DskipTests compile
source "$PROJECT_DIR/scripts/grpc-runtime.sh"
exec java -cp "$runtime_classpath" raftkv.tool.GrpcProcessClusterCheck "$@"
